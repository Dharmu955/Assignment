import { test, expect } from '@playwright/test';
import { AutocompletePage } from '../pages/autocomplete.page';
import {
  suggestions,
  matchingForAgileMethodology,
  invalidInput
} from '../config/test-data';

test.describe('Autocomplete form', () => {
  let autocomplete: AutocompletePage;

  test.beforeEach(async ({ page }) => {
    autocomplete = new AutocompletePage(page);
    await autocomplete.goto();
  });

  test('Suggestion filtering - prefix match', async () => {
    await autocomplete.type('agile method');

    const visible = await autocomplete.getVisibleSuggestions();

    expect(visible).toEqual(matchingForAgileMethodology);
  });

  test('Suggestion selection populates input', async () => {
    await autocomplete.selectSuggestion('agile methodology');

    await autocomplete.expectInputValue('agile methodology');
  });

  test('Tab navigation moves through interactive controls', async () => {
    await autocomplete.input.focus();

    await autocomplete.input.press('Tab');
    await expect(autocomplete.suggestions.first()).toBeFocused();

    await autocomplete.input.press('Tab');
    await expect(autocomplete.suggestions.nth(1)).toBeFocused();
  });

  test('Enter submits the selected value', async () => {
    await autocomplete.selectSuggestion('agile methodology');

    const responsePromise = autocomplete.page.waitForResponse(
      response => response.request().method() === 'POST' || response.request().method() === 'PUT'
    );

    await autocomplete.submitWithEnter();

    const response = await responsePromise;
    expect(response.status()).toBe(200);
    await autocomplete.expectSuccess();
  });

  test('Escape clears/closes the suggestion interaction', async () => {
    await autocomplete.type('agile');
    await autocomplete.pressEscape();

    // The exact clear/close implementation is application-specific.
    // The test confirms Escape is sent without submitting the form.
    await expect(autocomplete.nextButton).toBeVisible();
  });

  test('Valid submission displays success', async () => {
    await autocomplete.selectSuggestion('agile methodology');

    const responsePromise = autocomplete.page.waitForResponse(
      response => response.request().method() === 'POST' || response.request().method() === 'PUT'
    );

    await autocomplete.nextButton.click();

    const response = await responsePromise;
    expect(response.status()).toBe(200);
    await autocomplete.expectSuccess();
  });

  test('Invalid input displays error', async () => {
    await autocomplete.type(invalidInput);
    await autocomplete.nextButton.click();

    await autocomplete.expectError();
  });

  test('All provided suggestions are initially present', async () => {
    const visible = await autocomplete.getVisibleSuggestions();

    for (const item of suggestions) {
      expect(visible).toContain(item);
    }
  });
});
