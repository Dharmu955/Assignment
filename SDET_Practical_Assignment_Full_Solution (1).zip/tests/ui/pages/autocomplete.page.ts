import { expect, Locator, Page } from '@playwright/test';

export class AutocompletePage {
  readonly page: Page;
  readonly input: Locator;
  readonly suggestions: Locator;
  readonly nextButton: Locator;
  readonly errorMessage: Locator;
  readonly successMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.input = page.locator('#input-field');
    this.suggestions = page.locator('ul.suggestions li');
    this.nextButton = page.locator('#next-button');
    this.errorMessage = page.locator('.error-message');
    this.successMessage = page.locator('.success-container p');
  }

  async goto(): Promise<void> {
    await this.page.goto('/autocomplete-form');
  }

  async type(value: string): Promise<void> {
    await this.input.fill(value);
  }

  async selectSuggestion(value: string): Promise<void> {
    await this.suggestions.filter({ hasText: value }).first().click();
  }

  async submitWithEnter(): Promise<void> {
    await this.input.press('Enter');
  }

  async pressEscape(): Promise<void> {
    await this.input.press('Escape');
  }

  async getVisibleSuggestions(): Promise<string[]> {
    return this.suggestions.filter({ visible: true }).allTextContents();
  }

  async expectInputValue(value: string): Promise<void> {
    await expect(this.input).toHaveValue(value);
  }

  async expectSuccess(): Promise<void> {
    await expect(this.successMessage).toBeVisible();
  }

  async expectError(): Promise<void> {
    await expect(this.errorMessage).toBeVisible();
  }
}
