export const suggestions = [
  'agile methodology',
  'agile methodology process',
  'agile methodology process testing'
];

export const matchingForAgileMethodology = [
  'agile methodology',
  'agile methodology process',
  'agile methodology process testing'
];

export const invalidInput = 'invalid value';
