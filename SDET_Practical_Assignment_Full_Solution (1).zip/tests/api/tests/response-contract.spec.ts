import { test, expect } from '@playwright/test';

type FormResponse = {
  account_id: string;
  account_email: string;
  start_date: string;
  end_date: string;
  locale: string;
  text: string;
  suggestion_list: string;
  completed: boolean;
};

const API_BASE_URL = process.env.API_BASE_URL || 'https://test.com';
const API_GET_PATH = process.env.API_GET_PATH || '/api/responses/98765';

const requiredFields: (keyof FormResponse)[] = [
  'account_id',
  'account_email',
  'start_date',
  'end_date',
  'locale',
  'text',
  'suggestion_list',
  'completed'
];

function assertBcp47Locale(locale: string): void {
  // Practical validation for common BCP 47 language/region tags.
  // Examples accepted: en, en-IN, fr, hi-IN, zh-CN.
  expect(locale).toMatch(/^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/);
}

function assertLocalTimestamp(value: string): void {
  // Contract requires user-local time; therefore an explicit numeric
  // UTC offset is expected rather than a trailing Z.
  expect(value).toMatch(
    /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:[+-]\d{2}:\d{2})$/
  );
}

function assertResponseContract(body: unknown): asserts body is FormResponse {
  expect(body).toBeTruthy();
  expect(typeof body).toBe('object');

  const record = body as Record<string, unknown>;

  for (const field of requiredFields) {
    expect(record, `Missing required field: ${field}`).toHaveProperty(field);
  }

  expect(typeof record.account_id).toBe('string');
  expect(typeof record.account_email).toBe('string');
  expect(record.account_email).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);

  expect(typeof record.start_date).toBe('string');
  expect(typeof record.end_date).toBe('string');
  assertLocalTimestamp(record.start_date);
  assertLocalTimestamp(record.end_date);

  const start = Date.parse(record.start_date);
  const end = Date.parse(record.end_date);
  expect(Number.isNaN(start)).toBeFalsy();
  expect(Number.isNaN(end)).toBeFalsy();
  expect(end).toBeGreaterThanOrEqual(start);

  expect(typeof record.locale).toBe('string');
  assertBcp47Locale(record.locale);

  expect(typeof record.text).toBe('string');
  expect(typeof record.suggestion_list).toBe('string');

  expect(typeof record.completed).toBe('boolean');
}

function assertMatchingSuggestions(text: string, suggestionList: string[]): void {
  for (const suggestion of suggestionList) {
    expect(suggestion.length).toBeGreaterThan(0);
    // Default contract is prefix match.
    expect(suggestion.toLocaleLowerCase()).toSatisfy((value: string) =>
      value.startsWith(text.toLocaleLowerCase())
    );
  }
}

test.describe('FR-05 API contract', () => {
  test('Valid GET response matches FR-05 and suggestion filtering', async ({ request }) => {
    const response = await request.get(`${API_BASE_URL}${API_GET_PATH}`);

    expect(response.status()).toBe(200);

    const body = await response.json();
    assertResponseContract(body);

    const suggestions = body.suggestion_list
      .split(',')
      .map(value => value.trim())
      .filter(Boolean);

    assertMatchingSuggestions(body.text, suggestions);
  });

  test('Negative - missing required field is rejected by contract validator', async () => {
    const invalid: Record<string, unknown> = {
      account_id: '98765',
      // account_email intentionally missing
      start_date: '2024-03-15T16:00:00+05:30',
      end_date: '2024-03-15T16:02:00+05:30',
      locale: 'en-IN',
      text: 'agile methodology',
      suggestion_list: 'agile methodology, agile methodology process',
      completed: true
    };

    expect(() => assertResponseContract(invalid)).toThrow();
  });

  test('Negative - completed string is rejected because Boolean is required', async () => {
    const invalid = {
      account_id: '98765',
      account_email: 'test123@gmail.com',
      start_date: '2024-03-15T16:00:00+05:30',
      end_date: '2024-03-15T16:02:00+05:30',
      locale: 'en-IN',
      text: 'agile methodology',
      suggestion_list: 'agile methodology',
      completed: 'true'
    };

    expect(() => assertResponseContract(invalid)).toThrow();
  });

  test('Negative - UTC Z timestamp is rejected for local-time contract', async () => {
    const invalid = {
      account_id: '98765',
      account_email: 'test123@gmail.com',
      start_date: '2024-03-15T10:30:00Z',
      end_date: '2024-03-15T10:32:00Z',
      locale: 'en-IN',
      text: 'agile methodology',
      suggestion_list: 'agile methodology',
      completed: true
    };

    expect(() => assertResponseContract(invalid)).toThrow();
  });
});
