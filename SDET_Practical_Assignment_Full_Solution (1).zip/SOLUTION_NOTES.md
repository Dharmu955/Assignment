# Solution Notes

The supplied assignment is 5 pages and asks for Tasks 1–6 plus a Git repository structure.

Key FR-05 findings:
- start_date/end_date use `Z` (UTC), conflicting with the requirement for user-local timestamps in an India test environment.
- locale `en` is valid BCP 47, but may be incomplete versus the stated English/India environment (`en-IN`) if actual locale is required.
- completed is `"true"` (string), but must be Boolean `true`.
- suggestion_list is NOT a defect for the supplied `agile methodology` example because all three suggestions match the entered prefix.

The automation intentionally makes API endpoint configuration external because the PDF does not define a concrete REST endpoint.
