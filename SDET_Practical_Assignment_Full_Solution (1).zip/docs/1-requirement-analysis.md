# 1. Requirement Analysis

## Functional requirements

| ID | Requirement | Test interpretation |
|---|---|---|
| FR-01 | User can type any response or select a suggestion | Verify free text entry and suggestion click |
| FR-02 | Default filtering is prefix matching | Only suggestions beginning with entered text remain |
| FR-03 | Optional backend configuration supports match-anywhere | When enabled, suggestions containing text anywhere remain |
| FR-04 | Next sends REST call and handles success/invalid input | Verify 200 + success, invalid input + error |
| FR-05 | Persisted response has seven required properties | Validate fields, types, timestamps, locale, text, suggestions, completion |

## Important ambiguities / assumptions

1. The assignment provides a UI URL but no concrete API URL/path. The API suite therefore makes the API endpoint configurable.
2. The assignment provides static HTML, but not JavaScript implementation details. Enter/Escape behavior and dynamic filtering are treated as acceptance behavior.
3. The locale must follow IETF BCP 47. `en-IN` is the expected locale for the stated English/India environment; `en` is also syntactically valid BCP 47 but does not represent the stated regional locale.
4. `start_date` and `end_date` are required to represent the user's local time. A trailing `Z` represents UTC, so the supplied example is inconsistent with the stated local-time contract.
5. `completed` must be a Boolean, not a string.
6. `suggestion_list` must contain only suggestions matching the entered/selected value. For `agile methodology`, all three supplied suggestions start with that phrase, so all three are matching suggestions in this particular example.

## Risk model

Risk is ranked primarily by:
- user data loss / incorrect persistence
- contract violations affecting downstream systems
- core form submission failures
- filtering correctness
- keyboard/accessibility behavior
- lower-impact UI issues
