# 4. Detailed Test Cases

## TC-UI-001 – Prefix filtering

**Title:** Verify default prefix filtering  
**Preconditions:** User is logged in and autocomplete form is displayed; default filtering mode is prefix match.  
**Steps:**
1. Click the input.
2. Type `agile`.
3. Observe the suggestion list.
4. Type `method` so the complete value is `agile method`.
**Expected Results:**
- Suggestions beginning with the entered text remain visible.
- Suggestions not beginning with the entered text disappear.
- For `agile method`, all three supplied suggestions remain because they begin with that phrase.
**Test Data:** `agile`, `agile method`

## TC-UI-002 – Suggestion selection

**Title:** Verify selecting a suggestion populates the input  
**Preconditions:** Form is displayed and suggestions are visible.  
**Steps:**
1. Click `agile methodology`.
2. Inspect the input value.
**Expected Results:** Input is populated exactly with `agile methodology`.
**Test Data:** `agile methodology`

## TC-UI-003 – Invalid submission

**Title:** Verify invalid input displays an error  
**Preconditions:** Form is displayed; user enters text that is not a valid suggestion.  
**Steps:**
1. Enter `invalid value`.
2. Click Next.
3. Observe the form.
**Expected Results:** Error message is displayed and the response is not treated as successfully completed.
**Test Data:** `invalid value`

## TC-UI-004 – Successful submission

**Title:** Verify valid suggestion submission displays success  
**Preconditions:** Form is displayed and a valid suggestion can be selected.  
**Steps:**
1. Click `agile methodology`.
2. Click Next.
3. Observe the response.
**Expected Results:** REST request is sent; successful response is HTTP 200; success message is displayed.
**Test Data:** `agile methodology`

## TC-UI-005 – Tab navigation

**Title:** Verify logical keyboard tab order  
**Preconditions:** Form is displayed and focus can be placed on the page.  
**Steps:**
1. Focus the input.
2. Press Tab repeatedly.
3. Observe focus progression.
**Expected Results:** Focus moves through interactive form elements in a logical order and is visibly identifiable.
**Test Data:** None

## TC-UI-006 – Enter and Escape

**Title:** Verify Enter submits and Escape clears/closes suggestion interaction  
**Preconditions:** Valid suggestion is selected; form is displayed.  
**Steps:**
1. Select `agile methodology`.
2. Press Enter.
3. Verify successful submission behavior.
4. Reload/reset the form.
5. Type `agile`.
6. Press Escape.
**Expected Results:** Enter performs the form's submit action; Escape clears or closes the suggestion interaction according to the implemented requirement without submitting invalid data.
**Test Data:** `agile methodology`, `agile`

## TC-API-001 – Valid FR-05 response

**Title:** Verify successful GET response matches FR-05 schema  
**Preconditions:** A completed response exists.  
**Steps:**
1. Send GET request.
2. Verify HTTP status.
3. Validate all required properties.
4. Validate types and formats.
**Expected Results:** All required properties exist and conform to the contract.
**Test Data:** Completed response for account `98765`

## TC-API-002 – Matching suggestion list

**Title:** Verify suggestion_list contains only matching suggestions  
**Preconditions:** Completed response exists for selected text `agile methodology`.  
**Steps:**
1. Send GET request.
2. Parse `text`.
3. Split `suggestion_list` by comma.
4. Verify each returned suggestion matches the configured filtering rule.
**Expected Results:** No unrelated suggestion is returned.
**Test Data:** Text `agile methodology`

## TC-API-003 – Negative missing field

**Title:** Verify response contract rejects a missing required property  
**Preconditions:** API contract validation function is available.  
**Steps:**
1. Create a response object without `account_email`.
2. Validate it against FR-05.
**Expected Results:** Contract validation fails and identifies the missing property.
**Test Data:** Valid response minus `account_email`

## TC-API-004 – Negative invalid type

**Title:** Verify completed must be Boolean  
**Preconditions:** API contract validation function is available.  
**Steps:**
1. Create a response where `completed` is `"true"`.
2. Validate it against FR-05.
**Expected Results:** Validation fails because `completed` must be Boolean.
**Test Data:** `completed: "true"`
