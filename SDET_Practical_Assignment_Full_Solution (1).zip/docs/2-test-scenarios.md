# 2. Top 10 Test Scenarios – Risk Ranked

| Rank | Scenario | Risk | Rationale |
|---:|---|---|---|
| 1 | Submit a valid selected suggestion and verify the response is persisted correctly | Critical | This is the core business outcome and a failure can cause lost or incorrect user data. |
| 2 | Verify persisted API response conforms exactly to FR-05 contract | Critical | Contract violations can break consumers and silently corrupt analytics/integration data. |
| 3 | Submit invalid/free text and verify it is rejected with an error and is not marked completed | High | Invalid data reaching persistence creates data-quality and workflow problems. |
| 4 | Verify `start_date` and `end_date` represent correct user-local timestamps and end is after start | High | Incorrect timing data affects auditing, reporting and duration calculations. |
| 5 | Verify suggestion filtering under default prefix-match mode | High | Incorrect filtering can lead to wrong selections and directly affects the form's main interaction. |
| 6 | Verify configurable match-anywhere filtering | High | This is explicitly configurable behavior and incorrect implementation changes which values users can select. |
| 7 | Verify keyboard navigation, Enter submission and Escape behavior | Medium | Keyboard failures reduce usability and accessibility and can block non-mouse workflows. |
| 8 | Verify clicking a suggestion populates the input with the exact selected value | Medium | Incorrect population can result in submitting a value different from the user's selection. |
| 9 | Verify `completed` is Boolean and locale is valid BCP 47 | Medium | These type/format defects can break consumers even when the main response looks correct. |
| 10 | Verify Tab navigation follows a logical order across input, suggestions and Next | Low | It is important for accessibility but has lower direct data-integrity risk than submission/contract defects. |
