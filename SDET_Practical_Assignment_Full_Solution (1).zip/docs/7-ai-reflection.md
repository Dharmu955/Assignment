# 7. AI Reflection

## a. Tools Used

- ChatGPT (OpenAI) was used to assist with requirement analysis, test scenario design, test case drafting, and automation-code generation.

## b. Usage Areas

AI assistance was used for:
1. Breaking the assignment into the requested repository structure.
2. Identifying risks and prioritizing the top 10 scenarios.
3. Comparing the sample API response with FR-05.
4. Drafting detailed UI/API test cases.
5. Creating Playwright TypeScript Page Object Model code.
6. Creating API contract/type validation utilities and negative tests.
7. Drafting README/setup instructions.

## c. Modifications Made

### Modification 1 – Locale interpretation
The generated analysis could treat `en` as simply valid and stop there. I retained the BCP 47 validity distinction but added an environment-specific observation: the test environment is English in India, so `en-IN` is the expected regional locale if the product stores the user's actual locale.

**Reason:** `en` is technically a valid BCP 47 tag, so calling it an unconditional schema error would be inaccurate.

### Modification 2 – suggestion_list discrepancy
I explicitly classified `suggestion_list` as correct for the supplied example instead of reporting it as a defect merely because it contains all three suggestions.

**Reason:** The selected text is `agile methodology`, and every supplied suggestion begins with that exact phrase. Therefore all three satisfy the default prefix-match rule.

### Modification 3 – API endpoint configurability
The API automation does not hard-code an invented endpoint. `API_BASE_URL` and `API_GET_PATH` are environment variables.

**Reason:** The assignment specifies the UI URL but does not specify the concrete REST endpoint.

### Modification 4 – UI automation as acceptance tests
The assignment supplies static HTML but does not include JavaScript implementation for filtering, Escape, Enter, or REST submission. The UI scripts therefore target the required behavior rather than pretending the static HTML alone implements it.

**Reason:** This avoids creating false assumptions about implementation details.

## d. AI Limitations

A key limitation is that AI cannot execute the assignment's real application/API from the information supplied in the PDF because no working backend endpoint or application source code is provided. Generated selectors, API paths, and runtime behavior therefore need to be verified against the actual environment.

Another limitation is that natural-language requirements can contain subtle distinctions, such as `en` being valid BCP 47 while still potentially being wrong for an India-specific user locale. Human review is required before marking that item as a confirmed defect.
