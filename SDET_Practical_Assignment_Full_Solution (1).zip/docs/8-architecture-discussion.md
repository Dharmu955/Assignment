# 8. Architecture Discussion

## Why Page Object Model?

The UI automation uses a Page Object Model because:
- selectors are centralized
- business actions are readable from test cases
- changes to locators are isolated
- reusable methods reduce duplication

## Proposed layers

```text
Test Specs
   |
   v
Page Objects
   |
   v
Playwright Browser
   |
   v
Autocomplete Application

API Tests
   |
   v
API Contract Helpers
   |
   v
Playwright APIRequestContext
   |
   v
REST API
```

## Why keep API tests separate?

UI tests verify user-visible behavior. API tests verify:
- HTTP behavior
- contract shape
- data types
- timestamps
- locale
- persisted suggestion filtering

Separating them makes failures easier to diagnose and keeps API tests fast.

## Configuration

Environment-specific values should not be embedded in tests:
- `UI_BASE_URL`
- `API_BASE_URL`
- `API_GET_PATH`

This supports local, QA, staging and CI environments without changing source code.

## Future improvements

For a production suite I would add:
- JSON Schema/OpenAPI contract validation
- authentication fixtures
- request/response logging on failure
- accessibility checks
- test data factories
- CI pipeline
- retries only for known transient infrastructure failures
- environment-specific configuration files/secrets
- API mocks for deterministic UI tests where backend instability is not under test
