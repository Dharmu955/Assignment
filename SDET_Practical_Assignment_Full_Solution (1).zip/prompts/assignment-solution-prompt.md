# Prompt used for AI assistance

Analyze the attached SDET Practical Assignment PDF and provide a complete, implementation-ready solution. Preserve the assignment's requirements and terminology. Produce:
1. Top 10 risk-ranked scenarios.
2. Detailed FR-05 discrepancy analysis of the supplied API response.
3. At least 8 detailed UI/API test cases.
4. Executable Playwright automation using TypeScript and Page Object Model covering tab navigation, Enter/Escape, filtering, suggestion selection, submission, and success/error behavior.
5. API automation covering FR-05 schema, data types, timestamp format, BCP 47 locale, matching suggestion_list, and at least two negative cases.
6. README, architecture discussion, AI reflection, and the required repository structure.
Do not invent an API endpoint when the assignment does not specify one; make it configurable. Clearly identify assumptions and ambiguities.
