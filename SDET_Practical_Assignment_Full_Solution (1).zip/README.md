# SDET Practical Assignment – Autocomplete Form

## Overview
This repository contains the complete solution for the provided SDET practical assignment.

### Stack
- Playwright + TypeScript
- Playwright Test runner
- Playwright APIRequestContext for API automation
- Page Object Model for UI automation

> The assignment gives an assumed UI URL and API behavior, but it does not provide a real API endpoint. The API base URL is therefore configurable through `API_BASE_URL`. The UI tests use the supplied URL by default.

## Requirements
- Node.js 18+
- npm

## Install
```bash
npm install
npx playwright install chromium
```

## Run UI tests
```bash
npm run test:ui
```

## Run API tests
Set the real API endpoint first:
```bash
# Windows PowerShell
$env:API_BASE_URL="https://test.com"

# macOS/Linux
export API_BASE_URL="https://test.com"
```

Then:
```bash
npm run test:api
```

The API tests expect the GET endpoint to be configurable using `API_GET_PATH` (default: `/api/responses/98765`).

## Run everything
```bash
npm test
```

## View report
```bash
npm run report
```

## Important implementation note
The HTML supplied in the assignment is static markup and does not define JavaScript behavior for filtering, Escape, Enter, or API submission. Therefore, the automation suite expresses the required behavior as executable acceptance tests against the expected application implementation. Replace selectors/endpoints if the real application differs.

## Repository structure
```text
.
├── README.md
├── package.json
├── playwright.config.ts
├── docs/
│   ├── 1-requirement-analysis.md
│   ├── 2-test-scenarios.md
│   ├── 3-defect-identification.md
│   ├── 4-test-cases.md
│   ├── 7-ai-reflection.md
│   └── 8-architecture-discussion.md
├── tests/
│   ├── ui/
│   │   ├── pages/
│   │   │   └── autocomplete.page.ts
│   │   ├── tests/
│   │   │   └── autocomplete.spec.ts
│   │   └── config/
│   │       └── test-data.ts
│   └── api/
│       └── tests/
│           └── response-contract.spec.ts
└── prompts/
    └── assignment-solution-prompt.md
```

## Assignment mapping
- Task 1 → `docs/2-test-scenarios.md`
- Task 2 → `docs/3-defect-identification.md`
- Task 3 → `docs/4-test-cases.md`
- Task 4 → `tests/ui/` + README
- Task 5 → `tests/api/tests/response-contract.spec.ts`
- Task 6 → `docs/7-ai-reflection.md`
- Architecture discussion → `docs/8-architecture-discussion.md`
